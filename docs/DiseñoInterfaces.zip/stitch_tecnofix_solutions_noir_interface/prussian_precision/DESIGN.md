---
name: Prussian Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#45464d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#525e7d'
  primary: '#000a24'
  on-primary: '#ffffff'
  primary-container: '#14213d'
  on-primary-container: '#7c89aa'
  inverse-primary: '#b9c6ea'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#140900'
  on-tertiary: '#ffffff'
  tertiary-container: '#331d00'
  on-tertiary-container: '#c07a00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b9c6ea'
  on-primary-fixed: '#0d1b36'
  on-primary-fixed-variant: '#3a4664'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Josefin Sans
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  display-lg-mobile:
    fontFamily: Josefin Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg:
    fontFamily: Josefin Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Josefin Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Josefin Sans
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Josefin Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Jost
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Jost
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Jost
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Jost
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Jost
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Jost
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-utility minimalism engineered for high-performance SaaS platforms. Drawing architectural rigor from Linear and editorial polish from Stripe, it prioritizes clarity, informational density without clutter, and deliberate craftsmanship.

The visual style is strictly Minimalist with an emphasis on subtle physical realism: flat structural planes, hairline perimeter borders, and hyper-subtle diffuse elevation instead of synthetic glows. Interactions are swift, mechanical, and quiet. The emotional atmosphere is stable, executive, and frictionless—giving operators complete focus over high-stakes workflows.

## Colors

The palette establishes a high-fidelity light workspace centered on crisp contrast ratios meeting WCAG AA requirements (4.5:1 minimum for body text, 3:1 for graphical elements).

- **Base Canvas (`#F8FAFC`)**: Ultra-clean slate-tinted canvas to prevent eye fatigue while preserving separation from white cards.
- **Card & Container Surfaces (`#FFFFFF`)**: Pure white elevated modules offering high visual crispness against the canvas.
- **Borders & Dividers (`#E2E8F0`)**: Hairline boundary lines creating defined visual compartments without visual noise.
- **Primary Charcoal (`#0F172A`)**: Primary text and high-priority headings, rendering at a 15.8:1 contrast ratio against white.
- **Secondary Slate (`#64748B`)**: Secondary text, captions, inactive icons, and metadata (4.6:1 contrast against pure white).
- **Prussian Navy (`#14213D`)**: Primary action tone, brand marks, and selected navigation states.
- **Amber Accent (`#D97706` / `#F59E0B`)**: Alert badges, highlighted counters, and warning indicators. `#D97706` is reserved for text and border accents on light surfaces to maintain 4.6:1 contrast; `#F59E0B` functions as surface fills and indicators.

## Typography

The type system blends the geometric grace of **Josefin Sans** for structural headers with the functional legibility of **Jost** for data grids, forms, and dense interface patterns.

- Headings set in Josefin Sans lean on optical tracking adjustments: `-0.02em` for sizes above `24px` to achieve tight editorial composition.
- Body, table data, and form labels use Jost set with normal tracking (`0em`) and tall optical heights for scanning velocity.
- Monospace figures (`font-variant-numeric: tabular-nums`) must be applied across analytical tables, currency displays, and financial metrics.

## Layout & Spacing

Layouts follow an 8pt base grid with a 4pt micro-scale for compact form controls and toolbars.

- **Grid Model**: 12-column fluid grid system with a maximum canvas clamp of `1440px`. Mobile viewports (<768px) collapse to a 4-column system with a `1rem` outer margin and gutter.
- **Rhythm**: Generous section padding (`space-xl` / 40px) gives structural separation between dashboard cards, while internal component density uses tighter increments (`space-xs` and `space-sm`) to support high-density workflows.
- **Alignment**: Hard left alignment across page anchors, card headers, and table cells. Numbers and metric delta badges align right.

## Elevation & Depth

Depth is established primarily through clean tonal separation and low-contrast borders rather than heavy drop shadows.

- **Flat Foundation**: Surfaces sit on a 1px solid border (`#E2E8F0`) over the `#F8FAFC` canvas.
- **Micro Shadow (Level 1 - Cards/Buttons)**: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`. Barely perceptible weight that anchors pure white elements onto off-white canvas.
- **Float Shadow (Level 2 - Menus/Popovers)**: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`. Paired with a 1px `#E2E8F0` border.
- **Overlay Shadow (Level 3 - Modals/Drawers)**: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03)`. Backed by an overlay tint of `#0F172A` at `0.2` opacity with zero blur.
- **Zero Glow Policy**: No colored drop shadows, outer glows, or diffusion under badges or primary buttons.

## Shapes

The interface embraces a tailored 6px to 8px rounded edge profile:

- **Tokens**: Level 1 defines default component corners at `0.25rem` (4px to 6px) and grouped card containers at `rounded-lg` (`0.5rem` / 8px).
- **Controls**: Form inputs, small buttons, segmented tabs, and chips use a strict 6px radius.
- **Containers**: Cards, modal dialogues, sheets, and preview panels use an 8px radius.
- **Status Pills**: Status indicators and circular avatar components use fully rounded geometries (`9999px`).

## Components

### Buttons
- **Primary**: Background `#14213D`, text `#FFFFFF`, 6px border radius, height 36px (compact) or 40px (default). Hover state: `#1E293B`. Active: subtle transform scale `0.99`.
- **Secondary / Outline**: Background `#FFFFFF`, 1px solid border `#E2E8F0`, text `#0F172A`. Hover: background `#F8FAFC`, border `#CBD5E1`.
- **Ghost**: Background transparent, text `#64748B`. Hover: background `#F1F5F9`, text `#0F172A`.
- **Accent**: Background `#D97706`, text `#FFFFFF`. Reserved strictly for primary conversion steps or subscription triggers.

### Cards & Panels
- **Container**: Background `#FFFFFF`, 1px border `#E2E8F0`, 8px corner radius, padding `1.5rem` (`space-lg`).
- **Header**: Clear division using 1px border-bottom `#F1F5F9`, padding-bottom `1rem`. Titles in Josefin Sans `headline-sm`, subtitle in Jost `body-sm` (`#64748B`).

### Form Controls & Inputs
- **Text Inputs**: Height 38px, background `#FFFFFF`, 1px border `#E2E8F0`, 6px corner radius, font size `14px`, text `#0F172A`, placeholder `#94A3B8`.
- **Focus State**: Hairline border transition to `#14213D` with a 2px outer ring offset in `rgba(20, 33, 61, 0.08)`. No aggressive blue/neon rings.
- **Checkboxes & Radios**: 16x16px, border 1px solid `#CBD5E1`, 4px radius (checkbox) or circular (radio). Checked state: fill `#14213D` with white checkmark.

### Badges & Chips
- **Neutral**: Background `#F1F5F9`, text `#475569`, 1px border `#E2E8F0`, 4px radius, 11px font weight 600.
- **Amber / Pending**: Background `#FEF3C7`, text `#B45309`, 1px border `#FDE68A`.
- **Active / Success**: Background `#ECFDF5`, text `#047857`, 1px border `#A7F3D0`.

### Data Tables
- **Header Cell**: Jost `label-sm`, uppercase, tracking `0.05em`, color `#64748B`, background `#F8FAFC`, height 36px, border-bottom 1px solid `#E2E8F0`.
- **Row Cell**: Jost `body-md`, color `#0F172A`, height 44px, border-bottom 1px solid `#F1F5F9`. Hover state: background `#F8FAFC`.