---
name: Technical Noir Precision
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#d9c3ad'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#a18e79'
  outline-variant: '#534433'
  surface-tint: '#ffb95f'
  primary: '#ffc887'
  on-primary: '#472a00'
  primary-container: '#fca311'
  on-primary-container: '#663f00'
  inverse-primary: '#855300'
  secondary: '#b9c6ea'
  on-secondary: '#23304d'
  secondary-container: '#3c4967'
  on-secondary-container: '#abb8db'
  tertiary: '#d1d2d2'
  on-tertiary: '#2f3131'
  tertiary-container: '#b6b6b6'
  on-tertiary-container: '#464848'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b9c6ea'
  on-secondary-fixed: '#0d1b36'
  on-secondary-fixed-variant: '#3a4664'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an uncompromising industrial noir aesthetic tailored for high-throughput enterprise hardware repair facilities and specialized electronics engineering labs. It rejects soft, generic SaaS tropes in favor of razor-sharp geometries, high-contrast structural line work, and an atmospheric darkness reminiscent of precision diagnostic equipment operating in clean-room environments.

### Core Tenets
- **Cinematic Technical Rigor:** Deep cinematic shadows combined with deliberate hairline boundaries evoke the precision of blueprint drafting and micro-soldering schematics.
- **Instrument-Grade Functionalism:** Every pixel serves operational clarity. Contrast ratios exceed standard compliance to guarantee split-second status recognition in both low-light testing bays and illuminated assembly floors.
- **Industrial Aristocracy:** Dark tones are anchored by deep Prussian Blue and obsidian black, highlighted with a focused, non-radiant warm industrial amber accent (#fca311) that feels forged rather than synthesized.
- **Zero Frivolity:** No emojis, no decorative gradient blobs, no synthetic neon glows. Visual authority is achieved strictly through typography, structural border hierarchy, and pure semantic data visualization.

## Colors

The system uses a strictly controlled chromatic hierarchy rooted in true black and deep atmospheric Prussian Blue, punctuated by a curated warm industrial amber.

### Palette Architecture
- **Obsidian Core (`#000000`):** The foundational substrate for page canvases, master shell backdrops, and deep recessed containers.
- **Prussian Blue (`#14213d`):** The structural mid-tone. Applied to secondary interactive surfaces, table headers, persistent navigation bars, and elevated contextual panels.
- **Industrial Amber (`#fca311`):** The primary intentional accent. Deliberately calibrated as a warm mechanical amber (evocative of tungsten indicators, high-temperature caution tape, and raw copper), strictly avoiding neon or oversaturated yellow frequencies. Reserved for active states, key conversion targets, in-progress stages, and critical focal elements.
- **Alabaster Gray (`#e5e5e5`):** The high-contrast technical neutral. Applied to primary headings, crisp mechanical dividers, hairline borders, and critical metric numerals.
- **Pure White (`#ffffff`):** Restricted to pinpoint focal text, selected states, and maximum-contrast diagnostic alerts.

### Supporting Sub-Surfaces & Dark Tones
- **Surface Elevation 00 (Canvas):** `#000000`
- **Surface Elevation 01 (Base Container):** `#080d18` (Prussian-tinted obsidian)
- **Surface Elevation 02 (Card / Module):** `#0e172a`
- **Surface Elevation 03 (Hover / Overlay):** `#14213d`
- **Border / Structural Rule:** `#1f2e4d` (default subtle), `#e5e5e5` (active/high-contrast mechanical boundary)
- **Text Primary:** `#ffffff`
- **Text Secondary:** `#e5e5e5`
- **Text Muted / Metadata:** `#7a889b`

### Status Palette (Desaturated / Technical)
- **En diagnóstico (In Diagnostics):** Background `rgba(20, 33, 61, 0.8)`, Border `#3a506b`, Text `#e5e5e5`
- **En reparación (Under Repair):** Background `rgba(252, 163, 17, 0.12)`, Border `#fca311`, Text `#fca311`
- **Esperando piezas (Awaiting Parts):** Background `rgba(186, 24, 27, 0.15)`, Border `#ba181b`, Text `#ff8fa3`
- **Listo para entrega (Ready for Handover):** Background `rgba(43, 147, 72, 0.15)`, Border `#2b9348`, Text `#70e000`

## Typography

The typographic hierarchy implements an uncompromising mechanical aesthetic using **Space Grotesk** for structured, geometric titles, tabular headers, and tracking IDs, paired with **Geist** for crisp, monospaced-adjacent legibility across complex diagnostics, serial strings, and technical documentation.

### Architectural Rules
- **Headers & Identifiers (Space Grotesk):** Applied with deliberate uppercase transforms on short labels and metadata tags (`label-sm`, `label-md`). Geometric shapes mirror the structural metalwork of chassis and circuit architectures.
- **Content & Technical Log Body (Geist):** Set with strict line heights to avoid collision in tabular rows. Highly distinct character shapes preserve readability for mixed alphanumeric sequences (e.g., IMEI, PCB serial numbers, MAC addresses).
- **Tabular Numerals:** All numeric metric displays, stock counts, and timestamps must use OpenType tabular figure settings (`tnum`) to maintain vertical column alignment.

## Layout & Spacing

The layout model is governed by an engineering grid system with tight horizontal cohesion, emphasizing spatial economy and uninterrupted data scanning.

### Layout Mechanics
- **Grid Architecture:** A responsive 12-column layout on desktop viewports (`>= 1280px`) with persistent 280px left-hand monolithic sidebar. At tablet breakpoints (`768px - 1279px`), the grid reflows to 8 columns with a collapsible icon-rail navigation (72px). On mobile (`< 768px`), panels collapse to a strict 4-column flow with a compact top command bar.
- **Rhythm & Alignments:** Strict 4px base modular unit. Spacing tokens explicitly define spatial gaps between discrete units, ensuring high data density without cognitive clutter.
- **Workcell Modularity:** High-density technician dashboards utilize nested sub-grids where status, telemetry, and part inventories align precisely to column tracks with hairline 1px visual seams.

## Elevation & Depth

Depth in this design system is architectural and dimensional, built on sharp contrast, subtle luminance tiers, and surgical perimeter borders rather than soft, diffused atmospheric blurs.

### Principles of Depth
- **Zero Diffuse Shadows:** Traditional soft drop shadows are prohibited. The interface mimics physical electronic test benches and anodized aluminum casings.
- **Luminance Stacking:** Depth increases strictly through surface color shifting:
  - Base: `#000000` (deep recessed canvas)
  - Modules: `#080d18` with a 1px boundary of `#14213d`
  - Floating Panels & Flyouts: `#0e172a` with a 1px boundary of `#e5e5e5`
  - Active / Modal Top Layers: `#14213d` with high-contrast amber anchor borders (`#fca311`)
- **Hairline Mechanical Borders:** Separation is produced exclusively by 1px solid lines. Hover interactions shift border intensity rather than scaling or diffusing shadows.
- **Hard Technical Cast Shadows:** If spatial separation is required for flying modals, use a hard 4px offset shadow with zero blur radius: `box-shadow: 4px 4px 0px 0px #000000`.

## Shapes

The design system adopts a **Sharp (`0`)** shape language. All corners, frames, input controls, chips, and overlays terminate at absolute 90-degree right angles (0px border radius).

### Precision Geometry Rules
- **Chiseled Edges:** No element ever receives rounded corners. Rectangular purism reinforces the feeling of physical technical hardware, diagnostic monitors, and mechanical components.
- **Angled Accents (Optional Chamfer):** High-priority cards or system alert banners may utilize a mechanical 45-degree corner cut (chamfer of 6px via `clip-path`) on top-right corners to mimic industrial component housings.
- **Border Execution:** Hairline 1px borders are crisp, continuous, and unfeathered.

## Components

### Buttons
- **Primary Industrial:** Solid `#fca311` fill, `#000000` text, bold `Space Grotesk` uppercase. Zero border radius. Hover: `#ffffff` background with `#000000` text. Active: hairline `#e5e5e5` inner inset.
- **Secondary Noir:** Background `#14213d`, text `#ffffff`, 1px solid border `#1f2e4d`. Hover: border shifts to `#e5e5e5`, background transitions to `#1c2e56`.
- **Ghost / Technical Utility:** Transparent background, 1px solid `#1f2e4d`, text `#e5e5e5`. Hover: border `#fca311`, text `#fca311`.

### Status Badges (Technical Indicators)
Rectangular indicators, uppercase `label-sm` tracking with a lead 6px square indicator block.
- **En diagnóstico:** Slate dark container (`#14213d`), border `#3a506b`, text `#e5e5e5`. Indicator: `#7a889b`.
- **En reparación:** Dark amber-tinted container (`#1e180d`), border `#fca311`, text `#fca311`. Indicator: `#fca311`.
- **Esperando piezas:** Deep crimson tint container (`#200b0e`), border `#ba181b`, text `#ff8fa3`. Indicator: `#ba181b`.
- **Listo para entrega:** Deep emerald tint container (`#0c1a11`), border `#2b9348`, text `#70e000`. Indicator: `#2b9348`.

### Navigation (Noir Sidebar)
- Deep `#000000` base with a 1px solid right border (`#14213d`).
- Navigation items: Full-width rectangular rows, left-aligned, accompanied by geometric vector icons (monoline, 1.5px stroke, no fill).
- Active item: Background `#0e172a`, left 3px indicator line in `#fca311`, text `#ffffff`.

### Data Tables (Technical Diagnostics)
- Headers: `#080d18` background, uppercase `Space Grotesk` `label-md`, text `#7a889b`, bottom border 1px solid `#14213d`.
- Rows: Alternating zebra striping with `#000000` and `#05080f`. Bottom row divider 1px solid `#0f1828`. Hover row: `#0e172a` with a left border accent `#fca311`.
- Numeric & Data Cells: Set in `Geist` with tabular figures enabled. Monospaced display for asset tags, serial numbers, and hex codes.

### Cards & Modules
- Noir Container: Background `#080d18`, border 1px solid `#14213d`.
- High-Contrast Inversion Card: Used for critical real-time alerts or diagnostic hand-offs. Solid `#e5e5e5` background with `#000000` typography and 2px `#000000` internal structural dividing lines.

### Form Inputs
- Background `#000000`, 1px solid `#1f2e4d` border, text `#ffffff`, placeholder `#49576e`.
- Focus State: Border immediately snaps to `#fca311`, outline none.
- Labeling: Positioned above input in uppercase `label-sm` (`#7a889b`). Monospace readout for units/measurements (e.g., `Ω`, `V`, `mA`, `GB`) pinned to the right edge.

### Modal Overlays & Diagnostics HUD
- Backdrop: Heavy `#000000` tint with 85% opacity, backdrop blur 0px (pure optical occlusion).
- Modal Body: Background `#080d18`, border 2px solid `#e5e5e5`, hard mechanical shadow (`6px 6px 0px #000000`).
- Header Bar: Dark Prussian `#14213d` banner with uppercase technical title and explicit closing trigger.